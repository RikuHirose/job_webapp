<?php

namespace App\Repositories\Occupation;

use App\Repositories\Base\BaseRepositoryInterface;

interface OccupationRepositoryInterface extends BaseRepositoryInterface
{
		public function getBlankModel();
}
