<?php

namespace App\Presenters;

class UserPresenter extends Presenter
{
}