<div class="text-center">
  <div class="" style="background-color: #f7f7f7;
    font-size: 16px;
    font-weight: 600;
    border-radius: 4px;
    padding: 64px 0;">
    一致する条件の求人が見つかりませんでした
  </div>
  <div class="mt-5 mb-5">
    こちらはいかがですか？
  </div>
</div>

@each('components.jobs.indexCard', $allJobs, 'job')